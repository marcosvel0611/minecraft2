$teleport @s ^ ^ ^ ~$(rotation) ~
