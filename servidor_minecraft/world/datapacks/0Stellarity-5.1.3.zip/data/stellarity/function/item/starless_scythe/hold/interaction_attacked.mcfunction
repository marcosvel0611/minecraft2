data remove entity @s attack
scoreboard players reset @p[predicate=stellarity:item/holding/starless_scythe] stellarity.item.starless_scythe.time_since_attack
