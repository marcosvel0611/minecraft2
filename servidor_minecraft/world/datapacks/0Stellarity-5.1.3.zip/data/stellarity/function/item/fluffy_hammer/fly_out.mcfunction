tp @s ^ ^ ^1

