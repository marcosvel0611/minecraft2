execute if score @s stellarity.item.crest.bonus_dmg matches 1 run function stellarity:item/crest_of_the_end/sfx/1
execute if score @s stellarity.item.crest.bonus_dmg matches 2 run function stellarity:item/crest_of_the_end/sfx/2
execute if score @s stellarity.item.crest.bonus_dmg matches 3 run function stellarity:item/crest_of_the_end/sfx/3
